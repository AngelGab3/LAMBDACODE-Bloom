//
//  MenuApp.swift
//  Menu
//
//  Created by Verónica Velázquez Bonilla on 01/04/25.
//

import SwiftUI
struct MenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
